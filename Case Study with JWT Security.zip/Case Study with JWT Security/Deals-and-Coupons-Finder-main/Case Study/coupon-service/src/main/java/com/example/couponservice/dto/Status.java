package com.example.couponservice.dto;

public enum Status {
    CART,
    PAID
}
