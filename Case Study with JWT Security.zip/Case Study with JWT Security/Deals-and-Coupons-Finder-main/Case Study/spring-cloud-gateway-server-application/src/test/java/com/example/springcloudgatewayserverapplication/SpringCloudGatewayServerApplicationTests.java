package com.example.springcloudgatewayserverapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
