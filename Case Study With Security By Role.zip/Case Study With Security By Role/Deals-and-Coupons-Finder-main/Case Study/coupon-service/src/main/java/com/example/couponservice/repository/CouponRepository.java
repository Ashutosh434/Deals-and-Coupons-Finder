package com.example.couponservice.repository;

import com.example.couponservice.entity.Coupon;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface CouponRepository extends MongoRepository<Coupon, String> {
    List<Coupon> findAllByProductName(String name);
}

